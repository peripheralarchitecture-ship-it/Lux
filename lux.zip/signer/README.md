# Light signer

Offline PoC tooling that registers tool ownership, writes a trust
statement into an unsigned APK, signs the APK, and verifies the result. Requires
Python 3.11+, a JDK `keytool`, Android SDK `apksigner` and `apkanalyzer`, and
OpenSSL 3.

Run commands from this directory with `python -m lightsigner`. Use `--help` on
the command or a subcommand for all arguments.

```sh
export LIGHT_SIGNER_KEY_PASSWORD='replace-me'
export LIGHT_SIGNER_STAMP_KEY_PASSWORD='replace-me-too'
# Generate the APK signing key.
python -m lightsigner keygen --tool-id com.example.tool --keys-dir keys
# Generate the shared RSA source-stamp key used by apksigner.
python -m lightsigner stamp-keygen --output-dir stamp-key

# Write the trust statement. No signing keys are used by this command.
python -m lightsigner inject-trust-statement --apk tool-unsigned.apk --build-recipe recipe.json \
  --registry registry.json --dev-id dev_example --build-id build_example \
  --keys-dir keys --out tool-with-statement.apk

# Sign and verify the APK containing the statement.
python -m lightsigner sign --apk tool-with-statement.apk --build-recipe recipe.json \
  --registry registry.json --build-id build_example --keys-dir keys \
  --stamp-keystore stamp-key/signing.p12 --stamp-key-alias light-stamp \
  --out tool.apk --signed-metadata signed.json

# Perform offline verification of the APK.
python -m lightsigner verify --apk tool.apk \
  --stamp-cert-sha256 "$LIGHT_STAMP_CERT_SHA256"

# Create the ignored PoC bundle keypair once.
mkdir -p keys/bundle
openssl genpkey -algorithm Ed25519 -out keys/bundle/private.pem
openssl pkey -in keys/bundle/private.pem -pubout -out keys/bundle/public.pem

# Build and verify a detached trust bundle.
python -m lightsigner bundle build --portal portal.json --output-dir bundle \
  --private-key keys/bundle/private.pem
python -m lightsigner bundle verify --bundle-json bundle/bundle.json \
  --bundle-sig bundle/bundle.sig --public-key keys/bundle/public.pem
```

`registry.json` maps a tool ID to its developer and permanent APK signing key:

```json
{
  "com.example.tool": {
    "devId": "dev_example",
    "keyId": "com.example.tool"
  }
}
```

Keys are written below ignored `keys/`. This filesystem keystore is only for
the PoC. Production signing keys must be held by a KMS or HSM. The password is
read only from `LIGHT_SIGNER_KEY_PASSWORD`; the source-stamp password is read
from `LIGHT_SIGNER_STAMP_KEY_PASSWORD`. Commands fail if their password is absent.

External tools resolve from an explicit override, `PATH`, then Android tools from the latest tool
under `ANDROID_SDK_ROOT` or `ANDROID_HOME`.

The checked-in bundle vectors use keys prefixed `INSECURE-`. They are test-only
and must never be configured as device trust anchors.

`portal.json` requires `version`, `issuedAt`, `allow`, `block`,
`trustedStampCerts`, and `revokedStampCerts`, with no extra fields.
Do not include `schemaVersion`; the builder supplies it. Timestamps must use
UTC `YYYY-MM-DDTHH:MM:SSZ`. See [the format contract](../trust-format/README.md)
for numeric limits, image-pin ownership, and publication/retry behavior.
