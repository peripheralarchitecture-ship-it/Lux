"""Light signing-zone utilities."""
