# Declaring Tool Metadata

Every tool needs a handful of pieces of metadata: a unique id, a display name, a version, and a list of any permissions it will need to ask of LightOS. You declare all of these in a single file ([`tool/lighttool.toml`](../../tool/lighttool.toml)) and the SDK's build process will handle the job of injecting them into your compiled tool.

> [!NOTE]
> If you're familiar with Android development, you'll be used to putting this metadata into your `build.gradle` and/or `AndroidManifest.xml` files. This is still happening under the hood via our build plugin, we just wanted to create a single, simple place for tool devs to enter this info.

## The file

Drop a `lighttool.toml` at the root of your `tool/` module:

```toml
[tool]
id          = "com.example.mytool"             # Java package id, dotted, lowercase
label       = "My Tool"                        # Your tool's display name
versionCode = 1                                # monotonically-increasing integer
versionName = "1.0.0"                          # ^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$
permissions  = ["android.permission.CAMERA"]   # allowlisted permissions only
capabilities = []                              # allowlisted SDK features
serverPackage = "com.lightos"                  # LightOS package your tool connects to
orientation  = "portrait"                      # optional; omit for no orientation lock
```

## Fields

### `id` — your tool's unique identifier
A dotted, lowercase Java package identifier with at least two segments — e.g. `com.example.mytool`. Once a tool is published you can't change this without it being treated as a different tool, so pick something stable. If your tool is going in the Light tool library, this will need to be globally unique! We'll let you know if you're trying to pick one that's already been used.

### `label` — the name shown on the device
1–50 printable characters, no `<`, `>`, or control characters. This is what users see in the Light Phone launcher.

### `versionCode` — monotonically-increasing integer
Android refuses updates whose `versionCode` does not strictly exceed the installed one. The Light build server will reject a submission whose `versionCode` is not greater than the previous published build, so always bump this when shipping a new version.

### `versionName` — user-visible version string
Strict `major.minor.patch` semver only (e.g. `1.2.3`). No leading zeros, no
pre-release (`1.2.3-rc.1`), and no build metadata (`1.2.3+build`). This will be the version string we'll use to refer to the build internally, and display on the dashboard and in LightOS. `versionCode` is what controls Android update ordering.

### `permissions` — Android permissions your tool needs
An array of permission strings, each one from the allowlist below. Anything not on the list will fail the build. Each entry becomes a `<uses-permission>` element in the generated manifest.

### `capabilities` — optional SDK features

An array of capability names from the SDK allowlist. Omit it when the tool needs none. A capability may generate the permissions, manifest components, and runtime marker required by that feature.

Detached playback uses:

```toml
[tool]
capabilities = ["detached-audio"]
```

`detached-audio` generates the `FOREGROUND_SERVICE` and `FOREGROUND_SERVICE_MEDIA_PLAYBACK` permissions, the detached audio service, and the SDK marker checked by `LightAudio.newPlayer`. None of those permissions can be listed under `permissions`. The capability owns them, and the build fails with an error naming the capability to declare instead.

DASH playback uses:

```toml
[tool]
capabilities = ["audio-dash"]
```

`audio-dash` adds the media3 DASH source to your tool's dependencies, at the media3 version the SDK is built against. It is a capability rather than a dependency you declare because every tool would otherwise carry a format almost none of them play.

A tool that syncs with a server on the user's own network uses:

```toml
[tool]
capabilities = ["cleartext-http"]
```

`cleartext-http` sets `android:usesCleartextTraffic="true"` on the generated
`<application>`. Android otherwise refuses plain-HTTP connections, which are
the norm for self-hosted servers on a home network (a NAS, a printer, a
personal sync server at a `192.168.x` address). Declaring it here keeps the
opt-out reviewable in `lighttool.toml` rather than hidden in a manifest.

### `serverPackage` — the LightOS package your tool connects to
Must be `com.lightos`. The build fails on any other value unless you pass `-DlightSdk.allowAltServerPackage=true`. To build for the LightOS emulator, see [Building your tool for the emulator](../system_app/README.md#9-building-your-tool-for-the-emulator).

### `orientation` — optional screen orientation lock
Set to `"portrait"` to keep the tool in portrait orientation. Omit this field to
let the system choose the orientation.

## Permission allowlist

To keep tools focused and the platform safe, only a curated set of permissions is currently accepted. The current list lives in [`LightToolMetadata.kt`](../../plugin/src/main/kotlin/com/thelightphone/plugin/LightToolMetadata.kt) under `LightToolPolicy.ALLOWED_PERMISSIONS` (though keep in mind that a user's current install of LightOS may have a slightly different list!). If you need a permission that isn't on the list, please get in touch — we're happy to expand the list when there's a real use case for it.
